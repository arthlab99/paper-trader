# Build the APK from your Android phone

1. Create a new GitHub repository.
2. Upload the contents of this ZIP to the repository (not the ZIP file itself).
3. Open the **Actions** tab.
4. Select **Build Android APK**.
5. Tap **Run workflow**.
6. Wait for the green checkmark.
7. Open the completed workflow run.
8. Under **Artifacts**, download `paper-trader-release-apk`.
9. Extract the downloaded artifact and install `app-release.apk`.

No Flutter installation is required on your phone.

The workflow creates the Android platform files, installs Flutter dependencies, analyzes the project, runs tests, builds a release APK, and uploads it as an artifact.
