import 'package:flutter_test/flutter_test.dart';
import 'package:paper_trader/main.dart';

void main() {
  testWidgets('Paper Trader starts', (tester) async {
    await tester.pumpWidget(const PaperTraderApp());
    await tester.pumpAndSettle();
    expect(find.text('Paper Trader'), findsOneWidget);
  });
}
