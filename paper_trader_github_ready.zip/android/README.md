Run `flutter create .` in this project directory to generate the standard Android/iOS platform folders if they are not already present.
