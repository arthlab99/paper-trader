import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/position.dart';
import '../models/trade.dart';
import '../models/journal_entry.dart';

class StorageService {
  Future<SharedPreferences> get _prefs async => SharedPreferences.getInstance();

  Future<void> save({
    required double cash,
    required List<Position> positions,
    required List<Trade> trades,
    required List<JournalEntry> journal,
    required bool darkMode,
  }) async {
    final p = await _prefs;
    await p.setDouble('cash', cash);
    await p.setBool('darkMode', darkMode);
    await p.setString('positions', jsonEncode(positions.map((e)=>e.toJson()).toList()));
    await p.setString('trades', jsonEncode(trades.map((e)=>e.toJson()).toList()));
    await p.setString('journal', jsonEncode(journal.map((e)=>e.toJson()).toList()));
  }

  Future<Map<String,dynamic>> load() async {
    final p = await _prefs;
    List<dynamic> decode(String key) {
      final s = p.getString(key);
      if (s == null) return [];
      return jsonDecode(s) as List<dynamic>;
    }
    return {
      'cash': p.getDouble('cash') ?? 1000000.0,
      'darkMode': p.getBool('darkMode') ?? true,
      'positions': decode('positions').map((e)=>Position.fromJson(Map<String,dynamic>.from(e))).toList(),
      'trades': decode('trades').map((e)=>Trade.fromJson(Map<String,dynamic>.from(e))).toList(),
      'journal': decode('journal').map((e)=>JournalEntry.fromJson(Map<String,dynamic>.from(e))).toList(),
    };
  }

  Future<void> reset() async {
    final p = await _prefs;
    await p.clear();
  }
}
