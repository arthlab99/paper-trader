import 'package:flutter/material.dart';
import '../providers/app_controller.dart';
import '../widgets/price_chart.dart';

class ReplayScreen extends StatefulWidget {
  final AppController controller;
  const ReplayScreen({super.key,required this.controller});
  @override State<ReplayScreen> createState()=>_ReplayScreenState();
}

class _ReplayScreenState extends State<ReplayScreen> {
  String symbol='RELIANCE';
  int cursor=5;
  String decision='HOLD';

  @override
  Widget build(BuildContext context) {
    final i=widget.controller.find(symbol)!;
    final visible=i.history.sublist(0,cursor.clamp(2,i.history.length));
    final current=visible.last;
    return ListView(padding:const EdgeInsets.all(16),children:[
      Text('Historical Replay',style:Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.bold)),
      const Text('Practice after market hours. Future candles are hidden until you advance.'),
      const SizedBox(height:12),
      DropdownButtonFormField<String>(
        value:symbol,label:const Text('Instrument'),
        items:widget.controller.instruments.map((x)=>DropdownMenuItem(value:x.symbol,child:Text('${x.symbol} • ${x.exchange}'))).toList(),
        onChanged:(v)=>setState(()=>{symbol=v!,cursor=5,decision='HOLD'})),
      const SizedBox(height:12),
      Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(children:[
        Align(alignment:Alignment.centerLeft,child:Text('Replay candle $cursor / ${i.history.length}')),
        PriceChart(values:visible,height:230),
        Text('Decision price: ₹${current.toStringAsFixed(2)}',style:Theme.of(context).textTheme.titleMedium),
      ]))),
      const SizedBox(height:12),
      SegmentedButton<String>(
        segments:const [
          ButtonSegment(value:'BUY',label:Text('BUY')),
          ButtonSegment(value:'HOLD',label:Text('HOLD')),
          ButtonSegment(value:'SELL',label:Text('SELL')),
        ],
        selected:{decision},onSelectionChanged:(v)=>setState(()=>decision=v.first)),
      const SizedBox(height:12),
      FilledButton.icon(
        onPressed:cursor<i.history.length?()=>setState(()=>cursor++):null,
        icon:const Icon(Icons.skip_next),label:const Text('Reveal next candle')),
      OutlinedButton.icon(
        onPressed:()=>widget.controller.addJournal(symbol,decision,'Replay decision at ₹${current.toStringAsFixed(2)}','Review whether the next candle confirmed the decision.'),
        icon:const Icon(Icons.bookmark_add),label:const Text('Save decision to journal')),
      const SizedBox(height:10),
      const Text('Replay is a learning simulator. It does not represent an executable historical order book.'),
    ]);
  }
}
