import 'package:flutter/material.dart';
import '../providers/app_controller.dart';
import 'market_screen.dart';
import 'portfolio_screen.dart';
import 'replay_screen.dart';
import 'journal_screen.dart';
import 'learn_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  final AppController controller;
  const HomeScreen({super.key, required this.controller});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int index=0;

  @override
  Widget build(BuildContext context) {
    if (!widget.controller.loaded) return const Scaffold(body: Center(child:CircularProgressIndicator()));
    final pages=[
      MarketScreen(controller:widget.controller),
      PortfolioScreen(controller:widget.controller),
      ReplayScreen(controller:widget.controller),
      JournalScreen(controller:widget.controller),
      LearnScreen(),
      SettingsScreen(controller:widget.controller),
    ];
    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex:index,
        onDestinationSelected:(i)=>setState(()=>index=i),
        destinations: const [
          NavigationDestination(icon:Icon(Icons.show_chart),label:'Market'),
          NavigationDestination(icon:Icon(Icons.account_balance_wallet),label:'Portfolio'),
          NavigationDestination(icon:Icon(Icons.history),label:'Replay'),
          NavigationDestination(icon:Icon(Icons.menu_book),label:'Journal'),
          NavigationDestination(icon:Icon(Icons.school),label:'Learn'),
          NavigationDestination(icon:Icon(Icons.settings),label:'Settings'),
        ],
      ),
    );
  }
}
