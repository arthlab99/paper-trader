import 'package:flutter/material.dart';
import '../models/instrument.dart';
import '../providers/app_controller.dart';
import '../widgets/price_chart.dart';

class TradeScreen extends StatefulWidget {
  final AppController controller;
  final Instrument instrument;
  const TradeScreen({super.key,required this.controller,required this.instrument});
  @override State<TradeScreen> createState()=>_TradeScreenState();
}

class _TradeScreenState extends State<TradeScreen> {
  final qty=TextEditingController(text:'1');
  final limit=TextEditingController();
  final stop=TextEditingController();
  final target=TextEditingController();
  final note=TextEditingController();
  String type='MARKET';

  Future<void> order(String side) async {
    final q=int.tryParse(qty.text)??0;
    final err=await widget.controller.placeOrder(
      symbol:widget.instrument.symbol,side:side,quantity:q,orderType:type,
      limitPrice:double.tryParse(limit.text),stopLoss:double.tryParse(stop.text),
      target:double.tryParse(target.text),note:note.text);
    if(!mounted)return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(err??'$side order simulated successfully.')));
    if(err==null) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final i=widget.instrument;
    return Scaffold(
      appBar:AppBar(title:Text(i.symbol)),
      body:ListView(padding:const EdgeInsets.all(16),children:[
        Text(i.name,style:Theme.of(context).textTheme.titleLarge),
        Text('${i.exchange} • Paper trading only'),
        const SizedBox(height:12),
        Text('₹${i.price.toStringAsFixed(2)}',style:Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight:FontWeight.bold)),
        Text('${i.change>=0?'+':''}${i.change.toStringAsFixed(2)} (${i.changePct.toStringAsFixed(2)}%)'),
        const SizedBox(height:8),
        PriceChart(values:i.history,height:240),
        const SizedBox(height:12),
        DropdownButtonFormField<String>(
          value:type,label:const Text('Order type'),
          items:const [DropdownMenuItem(value:'MARKET',child:Text('Market')),DropdownMenuItem(value:'LIMIT',child:Text('Limit'))],
          onChanged:(v)=>setState(()=>type=v!)),
        const SizedBox(height:10),
        TextField(controller:qty,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Quantity',border:OutlineInputBorder())),
        if(type=='LIMIT') ...[
          const SizedBox(height:10),
          TextField(controller:limit,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Limit price',border:OutlineInputBorder())),
        ],
        const SizedBox(height:10),
        Row(children:[
          Expanded(child:TextField(controller:stop,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Stop-loss (optional)',border:OutlineInputBorder()))),
          const SizedBox(width:8),
          Expanded(child:TextField(controller:target,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Target (optional)',border:OutlineInputBorder()))),
        ]),
        const SizedBox(height:10),
        TextField(controller:note,maxLines:2,decoration:const InputDecoration(labelText:'Trade note (optional)',border:OutlineInputBorder())),
        const SizedBox(height:18),
        Row(children:[
          Expanded(child:FilledButton.icon(onPressed:()=>order('BUY'),icon:const Icon(Icons.arrow_upward),label:const Text('PAPER BUY'))),
          const SizedBox(width:10),
          Expanded(child:FilledButton.icon(onPressed:()=>order('SELL'),icon:const Icon(Icons.arrow_downward),label:const Text('PAPER SELL'))),
        ]),
        const SizedBox(height:10),
        const Text('Orders here are simulated locally. No broker/exchange order is sent.',textAlign:TextAlign.center),
      ]),
    );
  }
}
