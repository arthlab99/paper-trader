import 'package:flutter/material.dart';
import '../providers/app_controller.dart';
import '../models/instrument.dart';
import '../widgets/price_chart.dart';
import 'trade_screen.dart';

class MarketScreen extends StatefulWidget {
  final AppController controller;
  const MarketScreen({super.key, required this.controller});
  @override State<MarketScreen> createState()=>_MarketScreenState();
}

class _MarketScreenState extends State<MarketScreen> {
  String query='';
  @override
  Widget build(BuildContext context) {
    final list=widget.controller.instruments.where((i)=>
      i.symbol.toLowerCase().contains(query.toLowerCase()) ||
      i.name.toLowerCase().contains(query.toLowerCase())).toList();
    return Column(children:[
      Padding(
        padding: const EdgeInsets.fromLTRB(16,16,16,8),
        child: Row(children:[
          Expanded(child:Text('Paper Trader',style:Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.bold))),
          Chip(label:Text('₹${widget.controller.cash.toStringAsFixed(0)}')),
        ]),
      ),
      Padding(padding:const EdgeInsets.symmetric(horizontal:16),child:TextField(
        decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Search NSE / BSE companies',border:OutlineInputBorder()),
        onChanged:(v)=>setState(()=>query=v),
      )),
      const SizedBox(height:8),
      Expanded(child:ListView.builder(
        itemCount:list.length,
        itemBuilder:(_,idx){
          final i=list[idx];
          final up=i.change>=0;
          return Card(
            margin:const EdgeInsets.symmetric(horizontal:12,vertical:5),
            child:ListTile(
              title:Text(i.name,style:const TextStyle(fontWeight:FontWeight.w600)),
              subtitle:Text('${i.symbol} • ${i.exchange}'),
              trailing:Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.end,children:[
                Text('₹${i.price.toStringAsFixed(2)}',style:const TextStyle(fontWeight:FontWeight.bold)),
                Text('${up?'+':''}${i.changePct.toStringAsFixed(2)}%',style:TextStyle(color:up?Colors.green:Colors.red)),
              ]),
              onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>TradeScreen(controller:widget.controller,instrument:i))),
            ),
          );
        },
      )),
    ]);
  }
}
