import 'package:flutter/material.dart';
import '../providers/app_controller.dart';

class SettingsScreen extends StatelessWidget {
  final AppController controller;
  const SettingsScreen({super.key,required this.controller});

  @override
  Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[
    Text('Settings',style:Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.bold)),
    SwitchListTile(title:const Text('Dark mode'),value:controller.darkMode,onChanged:(_)=>controller.toggleTheme()),
    const Divider(),
    const ListTile(
      leading:Icon(Icons.security),
      title:Text('Paper trading safety'),
      subtitle:Text('This Phase 1 build cannot place real broker orders. API keys are not included.'),
    ),
    const ListTile(
      leading:Icon(Icons.cloud_off),
      title:Text('Data source'),
      subtitle:Text('Phase 1 uses bundled demonstration data. Live NSE/BSE integration is intentionally disabled.'),
    ),
    const SizedBox(height:20),
    FilledButton.tonalIcon(
      onPressed:()=>showDialog(context:context,builder:(c)=>AlertDialog(
        title:const Text('Reset account?'),
        content:const Text('This deletes local paper-trading positions, trades and journal entries and restores ₹10,00,000.'),
        actions:[
          TextButton(onPressed:()=>Navigator.pop(c),child:const Text('Cancel')),
          FilledButton(onPressed:()async{await controller.resetAccount();if(c.mounted)Navigator.pop(c);},child:const Text('Reset')),
        ],
      )),
      icon:const Icon(Icons.restart_alt),label:const Text('Reset paper account')),
  ]);
}
