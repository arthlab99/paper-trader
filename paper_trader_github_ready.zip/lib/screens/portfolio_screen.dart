import 'package:flutter/material.dart';
import '../providers/app_controller.dart';

class PortfolioScreen extends StatelessWidget {
  final AppController controller;
  const PortfolioScreen({super.key,required this.controller});

  @override
  Widget build(BuildContext context) {
    return ListView(padding:const EdgeInsets.all(16),children:[
      Text('Portfolio',style:Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.bold)),
      const SizedBox(height:12),
      Row(children:[
        Expanded(child:_stat('Cash',controller.cash)),
        Expanded(child:_stat('Invested',controller.invested)),
        Expanded(child:_stat('Unrealized',controller.unrealized)),
      ]),
      const SizedBox(height:20),
      Text('Positions',style:Theme.of(context).textTheme.titleLarge),
      const SizedBox(height:8),
      if(controller.positions.isEmpty)
        const Card(child:Padding(padding:EdgeInsets.all(20),child:Text('No open positions. Start with a paper trade.')))
      else ...controller.positions.map((p){
        final current=controller.price(p.symbol);
        final pnl=p.pnl(current);
        return Card(child:ListTile(
          title:Text(p.symbol,style:const TextStyle(fontWeight:FontWeight.bold)),
          subtitle:Text('${p.quantity} shares • Avg ₹${p.averagePrice.toStringAsFixed(2)} • LTP ₹${current.toStringAsFixed(2)}'),
          trailing:Text('${pnl>=0?'+':''}₹${pnl.toStringAsFixed(2)}',style:TextStyle(color:pnl>=0?Colors.green:Colors.red,fontWeight:FontWeight.bold)),
        ));
      }),
      const SizedBox(height:20),
      Text('Recent trades',style:Theme.of(context).textTheme.titleLarge),
      ...controller.trades.take(10).map((t)=>ListTile(
        leading:CircleAvatar(child:Icon(t.side=='BUY'?Icons.arrow_upward:Icons.arrow_downward)),
        title:Text('${t.side} ${t.symbol}'),
        subtitle:Text('${t.quantity} × ₹${t.price.toStringAsFixed(2)} • ${t.orderType}'),
        trailing:Text('${t.time.hour.toString().padLeft(2,'0')}:${t.time.minute.toString().padLeft(2,'0')}'),
      )),
    ]);
  }

  Widget _stat(String title,double value)=>Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(children:[
    Text(title,style:const TextStyle(fontSize:12)),const SizedBox(height:4),
    Text('₹${value.toStringAsFixed(0)}',style:const TextStyle(fontWeight:FontWeight.bold)),
  ])));
}
