import 'package:flutter/material.dart';
import '../providers/app_controller.dart';

class JournalScreen extends StatelessWidget {
  final AppController controller;
  const JournalScreen({super.key,required this.controller});

  @override
  Widget build(BuildContext context) {
    final total=controller.trades.length;
    final buys=controller.trades.where((t)=>t.side=='BUY').length;
    return ListView(padding:const EdgeInsets.all(16),children:[
      Text('Trading Journal',style:Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.bold)),
      const SizedBox(height:8),
      Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('Trade count: $total'),
        Text('Buy orders: $buys'),
        Text('Sell orders: ${total-buys}'),
        Text('Open positions: ${controller.positions.length}'),
      ]))),
      const SizedBox(height:12),
      if(controller.journal.isEmpty)
        const Card(child:Padding(padding:EdgeInsets.all(20),child:Text('Your replay decisions and notes will appear here.')))
      else ...controller.journal.map((j)=>Card(child:ListTile(
        title:Text('${j.symbol} • ${j.decision}'),
        subtitle:Text('${j.reason}\n${j.lesson}'),
        isThreeLine:true,
        trailing:Text('${j.time.day}/${j.time.month}'),
      ))),
    ]);
  }
}
