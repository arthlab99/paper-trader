import 'package:flutter/material.dart';

class LearnScreen extends StatelessWidget {
  const LearnScreen({super.key});
  @override
  Widget build(BuildContext context)=>ListView(
    padding:const EdgeInsets.all(16),
    children:[
      Text('Learn Trading',style:Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.bold)),
      const SizedBox(height:12),
      _lesson(context,'1. Market basics','Learn what NSE and BSE are, what a stock represents, and why prices move.'),
      _lesson(context,'2. Candlesticks','Open, high, low and close. Learn how candle bodies and wicks describe price movement.'),
      _lesson(context,'3. Support & resistance','Identify areas where price has repeatedly reacted. Treat them as zones, not guaranteed lines.'),
      _lesson(context,'4. Risk management','Use small position sizes, define invalidation before entering, and never risk money you cannot afford to lose.'),
      _lesson(context,'5. Stop-loss & targets','A stop-loss defines when your trade idea is wrong. A target defines your planned exit.'),
      _lesson(context,'6. Trading journal','Record the setup, reason, risk, result and lesson. Review patterns instead of chasing losses.'),
      _lesson(context,'7. Replay practice','Use Replay every day after market hours and make decisions without seeing future candles.'),
      const SizedBox(height:12),
      const Card(child:Padding(padding:EdgeInsets.all(16),child:Text('Educational only: paper trading does not guarantee future results. Avoid real-money trading until you understand risk and local regulations.'))),
    ],
  );

  Widget _lesson(BuildContext c,String title,String body)=>Card(
    child:ExpansionTile(title:Text(title,style:const TextStyle(fontWeight:FontWeight.bold)),children:[
      Padding(padding:const EdgeInsets.fromLTRB(16,0,16,16),child:Text(body))
    ])
  );
}
