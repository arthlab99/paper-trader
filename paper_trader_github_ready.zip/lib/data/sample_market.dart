import '../models/instrument.dart';

List<Instrument> sampleInstruments() {
  List<double> series(double start, List<double> moves) {
    var v = start;
    final out = <double>[v];
    for (final m in moves) {
      v += m;
      out.add(double.parse(v.toStringAsFixed(2)));
    }
    return out;
  }

  return [
    Instrument(symbol:'RELIANCE', name:'Reliance Industries', exchange:'NSE', price:2924.40, previousClose:2897.20,
      history:series(2775,[22,-8,31,14,-12,28,17,-5,35,-16,19,22,-7,11,29,-13,18,25,-6,21])),
    Instrument(symbol:'TCS', name:'Tata Consultancy Services', exchange:'NSE', price:4168.30, previousClose:4142.00,
      history:series(3970,[18,25,-12,31,17,-8,24,19,-11,28,16,-6,34,-18,27,22,-9,25,14,26])),
    Instrument(symbol:'HDFCBANK', name:'HDFC Bank', exchange:'NSE', price:1942.75, previousClose:1928.40,
      history:series(1840,[12,18,-6,22,14,-11,17,23,-8,19,12,-5,26,-9,21,16,-7,20,11,14])),
    Instrument(symbol:'INFY', name:'Infosys', exchange:'NSE', price:1535.10, previousClose:1519.80,
      history:series(1430,[14,-5,19,11,-7,22,15,-9,18,12,-4,25,-10,20,16,-6,21,13,-3,15])),
    Instrument(symbol:'ICICIBANK', name:'ICICI Bank', exchange:'NSE', price:1426.60, previousClose:1418.00,
      history:series(1360,[9,14,-4,18,10,-7,15,12,-6,20,11,-5,16,13,-4,19,8,-6,14,9])),
    Instrument(symbol:'SBIN', name:'State Bank of India', exchange:'NSE', price:824.25, previousClose:817.10,
      history:series(770,[8,11,-4,14,9,-6,13,10,-5,16,8,-4,12,9,-5,15,7,-3,10,8])),
    Instrument(symbol:'TATAMOTORS', name:'Tata Motors', exchange:'BSE', price:1048.50, previousClose:1039.00,
      history:series(990,[12,-7,18,9,-11,16,13,-8,20,-6,15,11,-9,18,12,-5,17,10,-7,9])),
    Instrument(symbol:'ITC', name:'ITC Limited', exchange:'BSE', price:432.20, previousClose:429.80,
      history:series(410,[4,7,-3,8,5,-2,6,7,-4,8,4,-2,7,5,-3,8,4,-2,6,5])),
    Instrument(symbol:'LT', name:'Larsen & Toubro', exchange:'NSE', price:3910.00, previousClose:3874.20,
      history:series(3650,[24,-12,31,22,-17,29,18,-9,35,-14,27,21,-11,32,19,-8,26,23,-13,31])),
    Instrument(symbol:'AXISBANK', name:'Axis Bank', exchange:'BSE', price:1215.90, previousClose:1203.00,
      history:series(1150,[11,15,-5,19,8,-7,17,12,-6,21,10,-4,16,14,-8,18,9,-5,13,12])),
  ];
}
