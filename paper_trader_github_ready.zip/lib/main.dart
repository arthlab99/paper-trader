import 'package:flutter/material.dart';
import 'providers/app_controller.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const PaperTraderApp());
}

class PaperTraderApp extends StatefulWidget {
  const PaperTraderApp({super.key});

  @override
  State<PaperTraderApp> createState() => _PaperTraderAppState();
}

class _PaperTraderAppState extends State<PaperTraderApp> {
  final controller = AppController();

  @override
  void initState() {
    super.initState();
    controller.load();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Paper Trader',
          themeMode: controller.darkMode ? ThemeMode.dark : ThemeMode.light,
          theme: ThemeData(
            useMaterial3: true,
            colorSchemeSeed: Colors.indigo,
            brightness: Brightness.light,
          ),
          darkTheme: ThemeData(
            useMaterial3: true,
            colorSchemeSeed: Colors.indigo,
            brightness: Brightness.dark,
          ),
          home: HomeScreen(controller: controller),
        );
      },
    );
  }
}
