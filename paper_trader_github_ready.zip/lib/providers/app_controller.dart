import 'package:flutter/foundation.dart';
import '../data/sample_market.dart';
import '../models/instrument.dart';
import '../models/position.dart';
import '../models/trade.dart';
import '../models/journal_entry.dart';
import '../services/storage_service.dart';

class AppController extends ChangeNotifier {
  final storage = StorageService();
  final instruments = sampleInstruments();
  final List<Position> positions = [];
  final List<Trade> trades = [];
  final List<JournalEntry> journal = [];

  double cash = 1000000;
  bool darkMode = true;
  bool loaded = false;

  Future<void> load() async {
    final data = await storage.load();
    cash = data['cash'];
    darkMode = data['darkMode'];
    positions..clear()..addAll(data['positions']);
    trades..clear()..addAll(data['trades']);
    journal..clear()..addAll(data['journal']);
    loaded = true;
    notifyListeners();
  }

  Instrument? find(String symbol) {
    try { return instruments.firstWhere((x)=>x.symbol==symbol); } catch (_) { return null; }
  }

  double price(String symbol) => find(symbol)?.price ?? 0;

  double get invested => positions.fold(0, (s,p)=>s + p.quantity * price(p.symbol));
  double get equity => cash + invested;
  double get unrealized => positions.fold(0, (s,p)=>s + p.pnl(price(p.symbol)));

  double get realized {
    // Approximation based on matched sell cash flows for Phase 1.
    double v = 0;
    for (final t in trades) {
      if (t.side == 'SELL') v += (t.price - averageCostAtSell(t.symbol, t.price)) * t.quantity;
    }
    return v;
  }

  double averageCostAtSell(String symbol, double sellPrice) {
    final p = positions.where((x)=>x.symbol==symbol).firstOrNull;
    return p?.averagePrice ?? sellPrice;
  }

  Future<String?> placeOrder({
    required String symbol,
    required String side,
    required int quantity,
    required String orderType,
    double? limitPrice,
    double? stopLoss,
    double? target,
    String note = '',
  }) async {
    if (quantity <= 0) return 'Quantity must be greater than zero.';
    final ins = find(symbol);
    if (ins == null) return 'Instrument not found.';
    final executionPrice = orderType == 'LIMIT' && limitPrice != null ? limitPrice : ins.price;
    final value = executionPrice * quantity;

    if (side == 'BUY') {
      if (cash < value) return 'Insufficient virtual cash.';
      cash -= value;
      final existing = positions.where((x)=>x.symbol==symbol).firstOrNull;
      if (existing == null) {
        positions.add(Position(symbol:symbol,name:ins.name,exchange:ins.exchange,quantity:quantity,averagePrice:executionPrice));
      } else {
        final total = existing.averagePrice * existing.quantity + value;
        existing.quantity += quantity;
        existing.averagePrice = total / existing.quantity;
      }
    } else {
      final existing = positions.where((x)=>x.symbol==symbol).firstOrNull;
      if (existing == null || existing.quantity < quantity) return 'Not enough shares to sell.';
      existing.quantity -= quantity;
      cash += value;
      if (existing.quantity == 0) positions.remove(existing);
    }

    trades.insert(0, Trade(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      time: DateTime.now(),
      symbol:symbol, side:side, quantity:quantity, price:executionPrice,
      orderType:orderType, note: note,
    ));
    await persist();
    notifyListeners();
    return null;
  }

  Future<void> addJournal(String symbol, String decision, String reason, String lesson) async {
    journal.insert(0, JournalEntry(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      time: DateTime.now(), symbol:symbol, decision:decision, reason:reason, lesson:lesson));
    await persist();
    notifyListeners();
  }

  Future<void> persist() => storage.save(
    cash: cash, positions: positions, trades: trades, journal: journal, darkMode: darkMode);

  Future<void> toggleTheme() async {
    darkMode = !darkMode;
    await persist();
    notifyListeners();
  }

  Future<void> resetAccount() async {
    await storage.reset();
    cash = 1000000;
    positions.clear();
    trades.clear();
    journal.clear();
    darkMode = true;
    await persist();
    notifyListeners();
  }
}
