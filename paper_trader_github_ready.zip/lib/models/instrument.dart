class Instrument {
  final String symbol;
  final String name;
  final String exchange;
  final double price;
  final double previousClose;
  final List<double> history;

  const Instrument({
    required this.symbol,
    required this.name,
    required this.exchange,
    required this.price,
    required this.previousClose,
    required this.history,
  });

  double get change => price - previousClose;
  double get changePct => previousClose == 0 ? 0 : change / previousClose * 100;
}
