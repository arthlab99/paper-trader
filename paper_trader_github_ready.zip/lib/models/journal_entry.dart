class JournalEntry {
  final String id;
  final DateTime time;
  final String symbol;
  final String decision;
  final String reason;
  final String lesson;

  JournalEntry({
    required this.id,
    required this.time,
    required this.symbol,
    required this.decision,
    required this.reason,
    required this.lesson,
  });

  Map<String, dynamic> toJson() => {
    'id': id, 'time': time.toIso8601String(), 'symbol': symbol,
    'decision': decision, 'reason': reason, 'lesson': lesson,
  };

  factory JournalEntry.fromJson(Map<String, dynamic> j) => JournalEntry(
    id: j['id'],
    time: DateTime.parse(j['time']),
    symbol: j['symbol'],
    decision: j['decision'],
    reason: j['reason'],
    lesson: j['lesson'],
  );
}
