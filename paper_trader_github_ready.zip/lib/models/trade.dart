class Trade {
  final String id;
  final DateTime time;
  final String symbol;
  final String side;
  final int quantity;
  final double price;
  final String orderType;
  final String note;

  Trade({
    required this.id,
    required this.time,
    required this.symbol,
    required this.side,
    required this.quantity,
    required this.price,
    required this.orderType,
    this.note = '',
  });

  Map<String, dynamic> toJson() => {
    'id': id, 'time': time.toIso8601String(), 'symbol': symbol,
    'side': side, 'quantity': quantity, 'price': price,
    'orderType': orderType, 'note': note,
  };

  factory Trade.fromJson(Map<String, dynamic> j) => Trade(
    id: j['id'],
    time: DateTime.parse(j['time']),
    symbol: j['symbol'],
    side: j['side'],
    quantity: j['quantity'],
    price: (j['price'] as num).toDouble(),
    orderType: j['orderType'],
    note: j['note'] ?? '',
  );
}
