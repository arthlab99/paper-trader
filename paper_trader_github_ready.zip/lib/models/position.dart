class Position {
  final String symbol;
  final String name;
  final String exchange;
  int quantity;
  double averagePrice;

  Position({
    required this.symbol,
    required this.name,
    required this.exchange,
    required this.quantity,
    required this.averagePrice,
  });

  double marketValue(double currentPrice) => quantity * currentPrice;
  double pnl(double currentPrice) => (currentPrice - averagePrice) * quantity;

  Map<String, dynamic> toJson() => {
    'symbol': symbol, 'name': name, 'exchange': exchange,
    'quantity': quantity, 'averagePrice': averagePrice,
  };

  factory Position.fromJson(Map<String, dynamic> j) => Position(
    symbol: j['symbol'],
    name: j['name'],
    exchange: j['exchange'],
    quantity: j['quantity'],
    averagePrice: (j['averagePrice'] as num).toDouble(),
  );
}
