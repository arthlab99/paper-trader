import 'dart:math';
import 'package:flutter/material.dart';

class PriceChart extends StatelessWidget {
  final List<double> values;
  final double height;
  const PriceChart({super.key, required this.values, this.height = 220});

  @override
  Widget build(BuildContext context) {
    if (values.length < 2) return const SizedBox();
    return SizedBox(
      height: height,
      child: CustomPaint(
        painter: _ChartPainter(values, Theme.of(context).colorScheme.primary),
      ),
    );
  }
}

class _ChartPainter extends CustomPainter {
  final List<double> v;
  final Color color;
  _ChartPainter(this.v, this.color);

  @override
  void paint(Canvas c, Size s) {
    final minV = v.reduce(min);
    final maxV = v.reduce(max);
    final range = max(0.01, maxV-minV);
    final p = Paint()..color=color..strokeWidth=2.5..style=PaintingStyle.stroke;
    final path = Path();
    for (var i=0;i<v.length;i++) {
      final x = i/(v.length-1)*s.width;
      final y = s.height - ((v[i]-minV)/range)*s.height*0.85 - s.height*0.05;
      if (i==0) path.moveTo(x,y); else path.lineTo(x,y);
    }
    c.drawPath(path,p);

    final grid = Paint()..color=Theme.of(c.context).dividerColor.withValues(alpha:.25)..strokeWidth=1;
    for (var i=1;i<5;i++) {
      final y=s.height*i/5;
      c.drawLine(Offset(0,y),Offset(s.width,y),grid);
    }
  }

  @override
  bool shouldRepaint(covariant _ChartPainter old) => old.v != v;
}
