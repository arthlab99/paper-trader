# Paper Trader — Phase 1

A phone-friendly Flutter paper-trading learning simulator.

## Included

- ₹10,00,000 virtual starting balance
- NSE/BSE-style instrument universe with sample/historical data
- Search and watchlist
- Candlestick-style price chart
- Virtual market and limit buys/sells
- Stop-loss and target fields
- Portfolio and P&L
- Trade history
- Trading journal
- Performance statistics
- Historical replay mode
- Beginner learning section
- Local persistence with SharedPreferences
- No real-money order API
- No broker credentials

## Important

Phase 1 intentionally does NOT connect to live NSE/BSE data. The data layer is isolated so a legitimate market-data provider can be connected in Phase 3 without exposing credentials in the APK.

## Run

```bash
flutter pub get
flutter run
```

Release APK:

```bash
flutter build apk --release
```

The APK will be at:

`build/app/outputs/flutter-apk/app-release.apk`

## Architecture

lib/
  main.dart
  models/
  data/
  services/
  providers/
  screens/
  widgets/
